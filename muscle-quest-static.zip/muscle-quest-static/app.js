(function(){
  // Icon rendering
  document.addEventListener('DOMContentLoaded', () => {
    if (window.lucide) window.lucide.createIcons();

    // Tab switching
    const pages = {
      home: document.getElementById('page-home'),
      log: document.getElementById('page-log'),
      measure: document.getElementById('page-measure'),
      profile: document.getElementById('page-profile'),
    };
    const navBtns = document.querySelectorAll('.nav-btn');
    navBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const tab = btn.getAttribute('data-tab');
        Object.values(pages).forEach(el => el.classList.remove('page-active'));
        pages[tab].classList.add('page-active');
        navBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        if (window.lucide) window.lucide.createIcons();
      });
    });

    // Session start/stop button
    const sessionBtn = document.getElementById('btn-session');
    const progressBar = document.getElementById('progress-bar');
    let started = false;
    sessionBtn.addEventListener('click', () => {
      started = !started;
      sessionBtn.textContent = started ? '終了' : '開始';
      // Simple demo: animate progress
      if (started) {
        let w = 62;
        const id = setInterval(() => {
          w += Math.random()*3;
          if (w >= 100) { w = 100; clearInterval(id); }
          progressBar.style.width = w.toFixed(1) + '%';
        }, 600);
      }
    });

    // Measurement cards logic
    function round1(n){ return Math.round(n*10)/10; }

    function updateMeasureCard(card){
      const inputs = Array.from(card.querySelectorAll('input'));
      const vals = inputs.map(i => parseFloat(i.value||'0')||0);
      const avg = vals.reduce((a,b)=>a+b,0)/vals.length;
      const baseline = parseFloat(card.getAttribute('data-baseline')||'0')||0;
      const delta = round1(avg - baseline);
      card.querySelector('.avg').textContent = round1(avg).toFixed(1);
      const deltaEl = card.querySelector('.delta');
      const deltaVal = card.querySelector('.delta-val');
      deltaVal.textContent = (delta >= 0 ? '+' : '') + delta.toFixed(1);
      deltaEl.classList.toggle('positive', delta >= 0);
      deltaEl.classList.toggle('negative', delta < 0);
    }

    document.querySelectorAll('.measure-card').forEach(card => {
      card.querySelectorAll('input').forEach(inp => {
        inp.addEventListener('input', () => updateMeasureCard(card));
      });
      updateMeasureCard(card);
    });

    // Chart.js simple line chart
    const ctx = document.getElementById('progressChart');
    if (ctx && window.Chart) {
      const data = {
        labels: ['4月','5月','6月','7月','8月'],
        datasets: [
          { label: '上腕', data: [33.0,33.6,34.1,34.9,35.2], borderWidth: 3, fill: false, tension: 0.3 },
          { label: '胸囲', data: [94,95,96,97,98], borderWidth: 3, fill: false, tension: 0.3 },
        ]
      };
      new Chart(ctx, {
        type: 'line',
        data,
        options: {
          responsive: true,
          plugins: {
            legend: { display: true },
            tooltip: { mode: 'index', intersect: false }
          },
          scales: {
            y: { min: 30, max: 100 }
          }
        }
      });
    }

    // Save button feedback
    const saveBtn = document.getElementById('btn-save');
    saveBtn.addEventListener('click', () => {
      saveBtn.disabled = true;
      saveBtn.textContent = '保存しました';
      setTimeout(() => { saveBtn.disabled = false; saveBtn.innerHTML = '<i data-lucide="check-circle"></i>保存してレベル反映'; if (window.lucide) window.lucide.createIcons(); }, 1200);
    });
  });
})();